import React, { useState } from 'react';
    import { useLocation } from 'react-router-dom';

    const TrackRegistration = () => {
      const location = useLocation();
      const { trackCount } = location.state || { trackCount: 0 };
      const [tracks, setTracks] = useState(Array(trackCount).fill({ hasBase: null, instruments: '', instrumentCount: '' }));

      const handleBaseChange = (index, value) => {
        const newTracks = [...tracks];
        newTracks[index].hasBase = value;
        setTracks(newTracks);
      };

      const handleInstrumentChange = (index, e) => {
        const newTracks = [...tracks];
        newTracks[index].instruments = e.target.value;
        setTracks(newTracks);
      };

      const handleInstrumentCountChange = (index, e) => {
        const newTracks = [...tracks];
        newTracks[index].instrumentCount = e.target.value;
        setTracks(newTracks);
      };

      return (
        <div>
          <h1>Diesis Garage - Preventivo Registrazione brani</h1>
          <p>Hai selezionato di registrare {trackCount} brani.</p>
          {tracks.map((track, index) => (
            <div key={index} className="form-group">
              <h2>Brano {index + 1}</h2>
              <p>Questo brano ha già una Base registrata o deve essere incisa da Zero?</p>
              <button className="registration-button" onClick={() => handleBaseChange(index, true)}>HA GIÀ UNA BASE REGISTRATA</button>
              <button className="registration-button" onClick={() => handleBaseChange(index, false)}>DEVE ESSERE INCISA DA ZERO</button>
              {track.hasBase !== null && (
                <div>
                  {track.hasBase ? (
                    <div>
                      <p>Quale strumento/i vuoi registrare sulla base?</p>
                      <input type="text" value={track.instruments} onChange={(e) => handleInstrumentChange(index, e)} />
                    </div>
                  ) : (
                    <div>
                      <p>Quanti strumenti vanno registrati per questo brano?</p>
                      <input type="number" value={track.instrumentCount} onChange={(e) => handleInstrumentCountChange(index, e)} />
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      );
    };

    export default TrackRegistration;
