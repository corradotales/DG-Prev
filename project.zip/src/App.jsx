import React, { useState } from 'react';
    import { useNavigate } from 'react-router-dom';

    const instruments = [
      "Voce Solista", "Voce Coro", "Chitarra Elettrica", "Chitarra Acustica",
      "Basso Elettrico", "Basso Acustico", "Batteria Acustica", "Batteria Elettrica",
      "Strumento a Fiato", "Pianoforte/Tastiere", "Percussioni", "Strumento ad Arco"
    ];

    const App = () => {
      const [musicianCount, setMusicianCount] = useState(1);
      const [musicians, setMusicians] = useState(Array(1).fill({ instrument: '', secondInstrument: '' }));
      const [confirmation, setConfirmation] = useState(null);
      const [registrationOption, setRegistrationOption] = useState(null);
      const [trackCount, setTrackCount] = useState(0);
      const navigate = useNavigate();

      const handleMusicianCountChange = (e) => {
        const count = parseInt(e.target.value, 10);
        setMusicianCount(count);
        setMusicians(Array(count).fill({ instrument: '', secondInstrument: '' }));
      };

      const handleInstrumentChange = (index, type, e) => {
        const newMusicians = [...musicians];
        newMusicians[index] = {
          ...newMusicians[index],
          [type]: e.target.value
        };
        setMusicians(newMusicians);
      };

      const handleConfirmation = (confirm) => {
        setConfirmation(confirm);
      };

      const handleRegistrationOption = (option) => {
        setRegistrationOption(option);
        if (option === 'brani') {
          const count = prompt("Quanti brani vuoi registrare?");
          setTrackCount(parseInt(count, 10));
          navigate('/track-registration', { state: { trackCount: parseInt(count, 10) } });
        }
      };

      const getSessionPrice = () => {
        const prices = {
          1: 10,
          2: 15,
          3: 20,
          4: 25,
          5: 25,
          6: 30,
          7: 35,
          8: 40,
          9: 45,
          10: 50
        };
        return prices[musicianCount] || 0;
      };

      return (
        <div>
          <h1>Diesis Garage - Il tuo Preventivo</h1>
          <div className="form-group">
            <label htmlFor="musicianCount">Numero di musicisti:</label>
            <select id="musicianCount" value={musicianCount} onChange={handleMusicianCountChange}>
              {[...Array(10).keys()].map(i => (
                <option key={i + 1} value={i + 1}>{i + 1}</option>
              ))}
            </select>
          </div>
          {musicians.map((musician, index) => (
            <div key={index} className="form-group">
              <label>Musicista {index + 1}</label>
              <select value={musician.instrument} onChange={(e) => handleInstrumentChange(index, 'instrument', e)}>
                <option value="">Seleziona strumento</option>
                {instruments.map(instrument => (
                  <option key={instrument} value={instrument}>{instrument}</option>
                ))}
              </select>
              <select value={musician.secondInstrument} onChange={(e) => handleInstrumentChange(index, 'secondInstrument', e)}>
                <option value="">Seleziona secondo strumento (eventuale)</option>
                {instruments.map(instrument => (
                  <option key={instrument} value={instrument}>{instrument}</option>
                ))}
              </select>
            </div>
          ))}
          <div className="summary">
            <h2>Riepilogo</h2>
            {musicians.map((musician, index) => (
              <div key={index}>
                <strong>Musicista {index + 1}:</strong> {musician.instrument} {musician.secondInstrument && `, ${musician.secondInstrument}`}
              </div>
            ))}
          </div>
          <div className="confirmation">
            <button className="confirm-button" onClick={() => handleConfirmation(true)}>Conferma</button>
            <button className="cancel-button" onClick={() => handleConfirmation(false)}>Annulla</button>
          </div>
          {confirmation && (
            <div className="registration-options">
              <p>Per quale motivo stai calcolando questo Preventivo?</p>
              <button className="registration-button" onClick={() => handleRegistrationOption('prove')}>Registrare la Sessione di Prove</button>
              <button className="registration-button" onClick={() => handleRegistrationOption('brani')}>Registrare brani</button>
            </div>
          )}
          {registrationOption === 'prove' && (
            <div className="registration-result">
              <p className="price-text">Il prezzo per Registrare la Sessione di Prove è di € <strong>{getSessionPrice()}.00</strong></p>
              <p className="price-text">Il prezzo indicato si riferisce alla sola Registrazione della Sessione di Prove, che è in aggiunta al prezzo dell'affitto della Sala Prove.</p>
            </div>
          )}
        </div>
      );
    };

    export default App;
